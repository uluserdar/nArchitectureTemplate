﻿namespace $safeprojectname$.Logging.Serilog.Messages;

public static class SerilogMessages
{
    public static string NullOptionsMessage =>
        "You have sent a blank value! Something went wrong. Please try again.";
}