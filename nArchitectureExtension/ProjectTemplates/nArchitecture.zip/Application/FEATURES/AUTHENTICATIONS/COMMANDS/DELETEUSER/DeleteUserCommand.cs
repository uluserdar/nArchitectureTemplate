﻿using AutoMapper;
using Core.$safeprojectname$.Pipelines.Authorization;
using Core.Security.Entities;
using $safeprojectname$.Features.Authentications.Dtos;
using $safeprojectname$.Features.Authentications.Rules;
using $safeprojectname$.Services.Repositories;
using MediatR;

namespace $safeprojectname$.Features.Authentications.Commands.DeleteUser
{
    public class DeleteUserCommand:IRequest<DeletedUserDto>
    {
        public int Id { get; set; }

        public class DeleteUserCommandHandler : IRequestHandler<DeleteUserCommand, DeletedUserDto>,ISecuredRequest
        {
            private readonly IMapper _mapper;
            private readonly IUserRepository _userRepository;
            private readonly AuthenticationBusinessRule _authenticationBusinessRule;
            public string[] Roles => new[] { nameof(DeleteUserCommand) };

            public DeleteUserCommandHandler(IMapper mapper, IUserRepository userRepository, AuthenticationBusinessRule authenticationBusinessRule)
            {
                _mapper = mapper;
                _userRepository = userRepository;
                _authenticationBusinessRule = authenticationBusinessRule;
            }

            public async Task<DeletedUserDto> Handle(DeleteUserCommand request, CancellationToken cancellationToken)
            {
                User user = await _userRepository.GetAsync(x => x.Id == request.Id,enableTracking:false);
                _authenticationBusinessRule.CheckIfExistsUser(user);

                User mappedUser = _mapper.Map<User>(request);
                User deletedUser = await _userRepository.DeleteAsync(mappedUser);
                DeletedUserDto deletedUserDto = _mapper.Map<DeletedUserDto>(deletedUser);

                return deletedUserDto;
            }
        }
    }
}
