﻿namespace $safeprojectname$.Pipelines.Logging;

public interface ILoggableRequest
{
}