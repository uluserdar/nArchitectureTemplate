﻿using Core.$safeprojectname$.Repositories;
using Core.Security.Entities;
using $safeprojectname$.Contexts;
using Application.Services.Repositories;

namespace Kodlama.io.Devs.$safeprojectname$.Repositories
{
    public class UserOperationClaimRepository : EfRepositoryBase<UserOperationClaim, BaseDbContext>, IUserOperationClaimRepository
    {
        public UserOperationClaimRepository(BaseDbContext context) : base(context) { }
    }
}
