﻿using Core.$safeprojectname$.Repositories;
using Core.Security.Entities;
using $safeprojectname$.Contexts;
using Application.Services.Repositories;

namespace Kodlama.io.Devs.$safeprojectname$.Repositories
{
    public class OperationClaimRepository : EfRepositoryBase<OperationClaim, BaseDbContext>, IOperationClaimRepository
    {
        public OperationClaimRepository(BaseDbContext context) : base(context) { }
    }
}
