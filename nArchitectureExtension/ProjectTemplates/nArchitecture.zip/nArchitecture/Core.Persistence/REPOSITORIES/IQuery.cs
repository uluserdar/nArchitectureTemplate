﻿namespace $safeprojectname$.Repositories;

public interface IQuery<T>
{
    IQueryable<T> Query();
}