﻿using AutoMapper;
using Core.Persistence.Paging;
using Core.Security.Entities;
using $safeprojectname$.Features.Authentications.Commands.DeleteUser;
using $safeprojectname$.Features.Authentications.Commands.RegisterUser;
using $safeprojectname$.Features.Authentications.Commands.UpdateUser;
using $safeprojectname$.Features.Authentications.Dtos;
using $safeprojectname$.Features.Authentications.Models;
using $safeprojectname$.Features.Authentications.Queries.GetByIdUser;
using $safeprojectname$.Features.Authentications.Queries.LoginUser;

namespace $safeprojectname$.Features.Authentications.Profiles
{
    public class MappingProfile:Profile
    {
        public MappingProfile()
        {
            CreateMap<User, RegisteredUserDto>().ReverseMap();
            CreateMap<User, RegisterUserCommand>().ReverseMap();
            CreateMap<User, LoginUserQuery>().ReverseMap();
            CreateMap<User, LoggedUserDto>().ReverseMap();
            CreateMap<LoggedUserDto,LoginUserQuery>().ReverseMap();
            CreateMap<User,UpdatedUserDto>().ReverseMap();
            CreateMap<User, UpdateUserCommand>().ReverseMap();
            CreateMap<User, DeletedUserDto>().ReverseMap();
            CreateMap<User, DeleteUserCommand>().ReverseMap();
            CreateMap<User,UserGetByIdDto>().ReverseMap();
            CreateMap<User, GetByIdUserQuery>().ReverseMap();
            CreateMap<User, UserListDto>().ReverseMap();
            CreateMap<IPaginate<User>, UserListModel>().ReverseMap();
        }
    }
}
