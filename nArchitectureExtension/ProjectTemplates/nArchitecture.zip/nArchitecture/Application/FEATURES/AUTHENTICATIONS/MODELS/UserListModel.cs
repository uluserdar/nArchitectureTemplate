﻿using Core.Persistence.Paging;
using $safeprojectname$.Features.Authentications.Dtos;

namespace $safeprojectname$.Features.Authentications.Models
{
    public class UserListModel:BasePageableModel
    {
        public IList<UserListDto> Items { get; set; }
    }
}
