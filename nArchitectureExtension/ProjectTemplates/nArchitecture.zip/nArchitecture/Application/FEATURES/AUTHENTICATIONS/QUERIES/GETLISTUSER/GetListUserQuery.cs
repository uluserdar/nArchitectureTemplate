﻿using AutoMapper;
using Core.$safeprojectname$.Pipelines.Authorization;
using Core.$safeprojectname$.Requests;
using Core.Persistence.Paging;
using Core.Security.Entities;
using $safeprojectname$.Features.Authentications.Models;
using $safeprojectname$.Services.Repositories;
using MediatR;

namespace $safeprojectname$.Features.Authentications.Queries.GetListUser
{
    public class GetListUserQuery:IRequest<UserListModel>,ISecuredRequest
    {
        public PageRequest PageRequest { get; set; }
        public string[] Roles => new[] { nameof(GetListUserQuery) };

        public class GetListUserQueryHandler : IRequestHandler<GetListUserQuery, UserListModel>
        {
            private readonly IMapper _mapper;
            private readonly IUserRepository _userRepository;

            public GetListUserQueryHandler(IMapper mapper, IUserRepository userRepository)
            {
                _mapper = mapper;
                _userRepository = userRepository;
            }

            public async Task<UserListModel> Handle(GetListUserQuery request, CancellationToken cancellationToken)
            {
                IPaginate<User> users = await _userRepository.GetListAsync(index: request.PageRequest.Page, size: request.PageRequest.PageSize);
                UserListModel getListUserModel=_mapper.Map<UserListModel>(users);

                return getListUserModel;
            }
        }
    }
}
