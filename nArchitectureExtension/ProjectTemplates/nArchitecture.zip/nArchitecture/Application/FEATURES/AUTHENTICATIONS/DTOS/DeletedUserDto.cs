﻿namespace $safeprojectname$.Features.Authentications.Dtos
{
    public class DeletedUserDto
    {
        public int Id { get; set; }
    }
}
