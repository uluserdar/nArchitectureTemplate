﻿namespace $safeprojectname$.Enums;

public enum AuthenticatorType
{
    None = 0,
    Email = 1,
    Otp = 2
}