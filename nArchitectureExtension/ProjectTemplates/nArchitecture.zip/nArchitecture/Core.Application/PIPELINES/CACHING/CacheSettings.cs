﻿namespace $safeprojectname$.Pipelines.Caching;

public class CacheSettings
{
    public int SlidingExpiration { get; set; }
}