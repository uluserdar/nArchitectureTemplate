﻿namespace $safeprojectname$.Pipelines.Authorization;

public interface ISecuredRequest
{
    public string[] Roles { get; }
}