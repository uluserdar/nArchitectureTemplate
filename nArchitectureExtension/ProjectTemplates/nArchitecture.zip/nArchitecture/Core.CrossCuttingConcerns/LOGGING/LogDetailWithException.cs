﻿namespace $safeprojectname$.Logging;

public class LogDetailWithException : LogDetail
{
    public string ExceptionMessage { get; set; }
}